module.exports = {
    JS_Library: [
        "./node_modules/jquery/dist/jquery.js",
        "./node_modules/bootstrap/dist/js/bootstrap.bundle.js",
        "./node_modules/feather-icons/dist/feather.min.js",
        "./node_modules/owl.carousel/dist/owl.carousel.js",
        "./node_modules/nicescroll/dist/jquery.nicescroll.js",
        "./src/library/js/app.js"
    ]
};
